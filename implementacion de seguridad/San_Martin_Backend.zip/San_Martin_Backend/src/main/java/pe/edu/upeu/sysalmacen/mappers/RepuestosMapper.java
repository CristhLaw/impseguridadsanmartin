package pe.edu.upeu.sysalmacen.mappers;

import org.mapstruct.Mapper;
import pe.edu.upeu.sysalmacen.dtos.RepuestosDTO;
import pe.edu.upeu.sysalmacen.model.Repuestos;
import pe.edu.upeu.sysalmacen.model.Usuario;

@Mapper(componentModel = "spring")
public interface RepuestosMapper extends GenericMappers<RepuestosDTO, Repuestos> {
}
