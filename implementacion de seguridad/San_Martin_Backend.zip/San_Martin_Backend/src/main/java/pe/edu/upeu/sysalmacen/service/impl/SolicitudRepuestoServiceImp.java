package pe.edu.upeu.sysalmacen.service.impl;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upeu.sysalmacen.dtos.SolicitudRepuestoDTO;
import pe.edu.upeu.sysalmacen.model.SolicitudRepuesto;
import pe.edu.upeu.sysalmacen.repository.*;
import pe.edu.upeu.sysalmacen.service.ISolicitudRepuestoService;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class SolicitudRepuestoServiceImp extends CrudGenericoServiceImp<SolicitudRepuesto, Long> implements ISolicitudRepuestoService {

    private final ISolicitudRepuestoRepository SolicitudRepuestoRepository;

    @Override
    protected ICrudGenericoRepository<SolicitudRepuesto, Long> getRepo() {
        return SolicitudRepuestoRepository;
    }
}
