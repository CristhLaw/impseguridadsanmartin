package pe.edu.upeu.sysalmacen.repository;

import pe.edu.upeu.sysalmacen.dtos.SrSinstockDTO;
import pe.edu.upeu.sysalmacen.model.SrSinstock;

public interface ISrSinstockRepository extends ICrudGenericoRepository<SrSinstock, Long>
{
}
