package pe.edu.upeu.sysalmacen.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import pe.edu.upeu.sysalmacen.dtos.SolicitudRepuestoDTO;
import pe.edu.upeu.sysalmacen.mappers.SolicitudRepuestoMapper;
import pe.edu.upeu.sysalmacen.model.SolicitudRepuesto;
import pe.edu.upeu.sysalmacen.service.ISolicitudRepuestoService;

import java.net.URI;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/solicitudrepo")

public class SolicitudRepuestoController {

    private final SolicitudRepuestoMapper solicitudRepuestoMapper;
    private final ISolicitudRepuestoService solicitudRepuestoService;

    @GetMapping
    public ResponseEntity<List<SolicitudRepuesto>> findAll() {
        List<SolicitudRepuesto> list = solicitudRepuestoService.findAll();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SolicitudRepuesto> findById(@PathVariable("id") Long id) {
        SolicitudRepuesto obj = solicitudRepuestoService.findById(id);
        return ResponseEntity.ok(obj);
    }

    @PostMapping
    public ResponseEntity<Void> save(@Valid @RequestBody SolicitudRepuesto dto) {
        SolicitudRepuesto obj = solicitudRepuestoService.save(dto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(obj.getIdSolicitud())
                .toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@PathVariable("id") Long id, @RequestBody SolicitudRepuesto dto) {
        dto.setIdSolicitud(id);
        SolicitudRepuesto obj = solicitudRepuestoService.update(id, dto);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        solicitudRepuestoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
