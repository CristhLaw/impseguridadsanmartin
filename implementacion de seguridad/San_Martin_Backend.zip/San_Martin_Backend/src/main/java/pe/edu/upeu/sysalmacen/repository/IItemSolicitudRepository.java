package pe.edu.upeu.sysalmacen.repository;

import pe.edu.upeu.sysalmacen.model.ItemSolicitud;

public interface IItemSolicitudRepository extends ICrudGenericoRepository<ItemSolicitud, Long>{
}
