package pe.edu.upeu.sysalmacen.repository;

import pe.edu.upeu.sysalmacen.model.Categoria;

public interface ICategoriaRepository extends ICrudGenericoRepository<Categoria, Long> {
}
