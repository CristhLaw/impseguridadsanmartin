package pe.edu.upeu.sysalmacen.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.sysalmacen.model.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class SolicitudRepuestoDTO {
    private Long idSolicitud;
    private Usuario usuario;
    private Bus bus;
    private String descripcionDeFalla;
    private Repuestos Repuestos;
    private SrSinstock sr_sinstock;
    private Herramientas herramientas;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SolicitudCADto {
        private Long idUsuario;
        private Long idBus;
        private String descripcionDeFalla;
        private Long idRepuestos;
        private Long idSinstock;
        private Long idHerramienta;
        private Integer cantidad;
    }
}
