package pe.edu.upeu.sysalmacen.dtos;

import jakarta.persistence.*;
import pe.edu.upeu.sysalmacen.model.Rol;

public class RolDTO {


    private Long idUsuario;


    private String nombre;

    private String descripcion;

}

