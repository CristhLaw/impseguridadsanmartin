package pe.edu.upeu.sysalmacen.service.impl;

public class MediaFileServiceImp {
}
