package pe.edu.upeu.sysalmacen.service;

import org.springframework.data.repository.CrudRepository;
import pe.edu.upeu.sysalmacen.dtos.SrSinstockDTO;
import pe.edu.upeu.sysalmacen.model.SrSinstock;


public interface ISrSinstockService extends ICrudGenericoService<SrSinstock, Long> {
}
