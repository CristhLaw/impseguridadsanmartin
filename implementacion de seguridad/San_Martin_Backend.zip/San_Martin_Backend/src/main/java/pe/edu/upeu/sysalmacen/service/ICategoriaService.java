package pe.edu.upeu.sysalmacen.service;

import pe.edu.upeu.sysalmacen.model.Categoria;

public interface ICategoriaService extends ICrudGenericoService<Categoria,Long> {
}
