package pe.edu.upeu.sysalmacen.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ItemSolicitud")
public class ItemSolicitud {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private SolicitudRepuesto solicitud;

    private Long itemId; // id del repuesto o herramienta
    private String tipo; // "Repuesto" o "Herramienta"
    private Integer cantidad;
}
