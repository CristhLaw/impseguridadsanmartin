package pe.edu.upeu.sysalmacen.repository;

import pe.edu.upeu.sysalmacen.model.Herramientas;

public interface IHerramientasRepository extends ICrudGenericoRepository<Herramientas, Long>{
}
