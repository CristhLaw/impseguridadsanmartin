package pe.edu.upeu.sysalmacen.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import pe.edu.upeu.sysalmacen.dtos.BusDTO;
import pe.edu.upeu.sysalmacen.mappers.BusMapper;
import pe.edu.upeu.sysalmacen.model.Bus;
import pe.edu.upeu.sysalmacen.service.IBusService;

import java.net.URI;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/buses")
public class BusController {

    private final IBusService busService;  // Usamos busService para la lógica de negocio
    private final BusMapper busMapper;

    // Método para obtener todos los buses
    @GetMapping
    public ResponseEntity<List<BusDTO>> findAll() {
        List<Bus> buses = busService.findAll();
        List<BusDTO> busDTOs = busMapper.toDtos(buses); // Mapeamos las entidades a DTOs
        return ResponseEntity.ok(busDTOs);
    }

    // Método para obtener un bus por su ID
    @GetMapping("/{id}")
    public ResponseEntity<BusDTO> findById(@PathVariable("id") Long id) {
        Bus bus = busService.findById(id);
        BusDTO busDTO = busMapper.toDto(bus); // Convertimos la entidad a DTO
        return ResponseEntity.ok(busDTO);
    }

    // Método para guardar un nuevo bus
    @PostMapping
    public ResponseEntity<Void> save(@Valid @RequestBody BusDTO dto) {
        Bus bus = busMapper.toEntity(dto); // Convertimos el DTO a entidad
        Bus savedBus = busService.save(bus);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(savedBus.getIdbus()).toUri();
        return ResponseEntity.created(location).build();
    }

    // Método para actualizar un bus
    @PutMapping("/{id}")
    public ResponseEntity<BusDTO> update(@PathVariable("id") Long id, @RequestBody BusDTO dto) {
        Bus bus = busMapper.toEntity(dto); // Convertimos el DTO a entidad
        bus.setIdbus(id);
        Bus updatedBus = busService.update(id, bus);
        BusDTO updatedBusDTO = busMapper.toDto(updatedBus); // Convertimos la entidad actualizada a DTO
        return ResponseEntity.ok(updatedBusDTO);
    }

    // Método para eliminar un bus por su ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        busService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
