package pe.edu.upeu.sysalmacen.dtos;


import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class BusDTO {


        private Long idbus;

        private String placa;

        private String numeroIdentificador;

        private String modelo;

        private String capacidad;

        private String estado;

        private String fechaAdquisicion;

        private LocalDateTime ultimoMantenimiento;

}
