package pe.edu.upeu.sysalmacen.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "san_solicitud_repuestos")
public class SolicitudRepuesto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_solicitud")
    private Long idSolicitud;

    // Clave foránea a Usuario
    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    // Clave foránea a Bus
    @ManyToOne
    @JoinColumn(name = "id_bus", nullable = false)
    private Bus bus;

    @Column(name = "descripcion_de_falla", length = 255)
    private String descripcionDeFalla;


    @ManyToOne
    @JoinColumn(name = "id_Repuestos", nullable = false)
    private Repuestos Repuestos;


    @ManyToOne
    @JoinColumn(name = "id_herramienta", nullable = false)
    private Herramientas herramientas;


    @Column(name = "estado", length = 255)
    private String estado;

//-------------------------------------------------------


}
