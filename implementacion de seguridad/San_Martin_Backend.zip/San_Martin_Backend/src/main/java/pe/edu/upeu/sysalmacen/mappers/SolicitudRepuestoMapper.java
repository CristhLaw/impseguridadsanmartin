package pe.edu.upeu.sysalmacen.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import pe.edu.upeu.sysalmacen.dtos.SolicitudRepuestoDTO;
import pe.edu.upeu.sysalmacen.model.SolicitudRepuesto;

@Mapper(componentModel = "spring")
public interface SolicitudRepuestoMapper extends GenericMappers<SolicitudRepuestoDTO, SolicitudRepuesto> {

    @Mapping(target = "bus", ignore = true)
    @Mapping(target = "usuario", ignore = true)
    SolicitudRepuesto toEntityFromDTO(SolicitudRepuestoDTO.SolicitudCADto SolicitudCrearDTO);
}
