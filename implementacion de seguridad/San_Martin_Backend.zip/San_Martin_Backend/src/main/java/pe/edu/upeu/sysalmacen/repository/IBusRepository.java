package pe.edu.upeu.sysalmacen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.sysalmacen.model.Bus;

import java.util.List;

public interface IBusRepository extends ICrudGenericoRepository<Bus, Long> {

}
