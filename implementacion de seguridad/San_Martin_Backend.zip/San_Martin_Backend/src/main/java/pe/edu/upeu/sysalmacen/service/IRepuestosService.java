package pe.edu.upeu.sysalmacen.service;

import pe.edu.upeu.sysalmacen.model.Repuestos;

public interface IRepuestosService  extends ICrudGenericoService<Repuestos, Long>{
}
