package pe.edu.upeu.sysalmacen.repository;

import pe.edu.upeu.sysalmacen.model.Repuestos;

public interface IRepuestosRepository extends ICrudGenericoRepository<Repuestos, Long>{
}
