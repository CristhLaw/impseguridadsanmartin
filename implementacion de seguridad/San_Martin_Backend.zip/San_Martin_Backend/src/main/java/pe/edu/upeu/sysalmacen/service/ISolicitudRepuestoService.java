package pe.edu.upeu.sysalmacen.service;



import pe.edu.upeu.sysalmacen.dtos.SolicitudRepuestoDTO;
import pe.edu.upeu.sysalmacen.model.SolicitudRepuesto;

public interface ISolicitudRepuestoService extends ICrudGenericoService<SolicitudRepuesto, Long>{


}
