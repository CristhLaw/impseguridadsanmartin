package pe.edu.upeu.sysalmacen.service;

import pe.edu.upeu.sysalmacen.model.Herramientas;

public interface IHerramientasService extends ICrudGenericoService<Herramientas, Long>{
}
