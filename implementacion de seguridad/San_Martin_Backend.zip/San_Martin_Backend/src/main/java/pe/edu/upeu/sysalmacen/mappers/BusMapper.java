package pe.edu.upeu.sysalmacen.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import pe.edu.upeu.sysalmacen.dtos.BusDTO;
import pe.edu.upeu.sysalmacen.model.Bus;

@Mapper(componentModel = "spring")
public interface BusMapper extends GenericMappers<BusDTO, Bus> {

}
